# Prompt dla Claude — Don Bosco FIFA Responsive Theme

Masz zaimplementować globalny redesign UI aplikacji Don Bosco w stylu FIFA / EA Sports FC premium. Styl ma działać na wszystkich zakładkach, nie tylko na stronie głównej.

## Najważniejsze zasady

1. Nie zmieniaj funkcjonalności aplikacji.
2. Nie zmieniaj routingu.
3. Nie zmieniaj nazw danych ani logiki biznesowej.
4. Zmień wyłącznie warstwę UI/CSS/komponenty layoutu.
5. Projektuj mobile-first, ale zaimplementuj pełną responsywność dla mobile, tablet i desktop.
6. Aplikacja ma obsługiwać dark mode i light mode.
7. Logo będzie dostarczone osobno w tym samym folderze pod nazwą `logoDonBosco`.
8. Użyj tego logo w navbarze jako dobrze widocznego znaku po lewej stronie.

## Kierunek wizualny

Styl: FIFA / EA Sports FC / sport premium.

Kolory:
- główny pomarańcz: `#ff5a00`,
- ciemne tło: `#08090c`,
- ciemne karty: `#11141a`,
- jasne tło: `#f7f7f8`,
- jasne karty: `#ffffff`,
- tekst główny dark: `#f8fafc`,
- tekst główny light: `#111827`.

## Navbar

Mobile:
- sticky top navbar,
- logo po lewej,
- napis `Don Bosco` wycentrowany,
- ikona dark/light mode po prawej,
- hamburger po prawej,
- ciemne lub jasne tło zależne od motywu,
- pomarańczowa linia/akcent na dole.

Tablet:
- logo po lewej,
- tytuł lub krótkie menu w centrum,
- ikony po prawej,
- większy padding.

Desktop:
- logo + `Don Bosco` po lewej,
- główne menu na środku: Home, Mecze, Tabela, Statystyki, Więcej,
- toggle theme po prawej,
- hamburger ukryty powyżej 1024 px,
- navbar ma wyglądać jak pasek z gry sportowej: gradient, subtelne ukośne linie, pomarańczowe akcenty.

## Layout globalny

Mobile:
- jedna kolumna,
- karty jedna pod drugą,
- bottom nav może pozostać.

Tablet:
- siatka 2 kolumn dla kart statystyk,
- tabela pełna szerokość,
- większe marginesy boczne.

Desktop:
- maksymalna szerokość contentu 1180–1280 px,
- dashboard grid,
- karty meczów i statystyk w układzie 2–3 kolumn,
- tabela szeroka i czytelna,
- hover states na kartach i przyciskach.

## Globalne komponenty do ostylowania

Zastosuj theme do:
- navbaru,
- bottom navigation,
- kart meczów,
- kart statystyk,
- tabeli ligowej,
- przełączników sezonu,
- buttonów,
- floating action button,
- ikon,
- backgroundu całej aplikacji.

## Dark mode

Dark mode ma być pełnym trybem aplikacji, nie tylko ciemnym navbarem.
Tło aplikacji ciemne, karty ciemne, tekst jasny, pomarańczowe akcenty.
Dodaj subtelny pattern w tle: dotted grid / ukośne linie / sportowy gradient.

## Light mode

Light mode ma być jasną wersją tego samego stylu.
Tło jasne, karty białe, tekst ciemny, pomarańczowe akcenty, navbar jasny z subtelnymi liniami.
Nie może wyglądać jak zupełnie inna aplikacja.

## Implementacja

Najpierw znajdź główny layout aplikacji, navbar oraz globalne style. Następnie:

1. Dodaj tokeny CSS z pliku `css/fifa-theme-tokens.css`.
2. Dodaj style layoutu z pliku `css/fifa-responsive-layout.css`.
3. Użyj assetu `assets/navbar-bg.svg` jako opcjonalnego tła navbaru.
4. Użyj `logoDonBosco` z folderu wskazanego przez użytkownika.
5. Ujednolić wygląd komponentów na wszystkich zakładkach.
6. Zachowaj istniejące eventy kliknięć, route linki, menu i toggle.

## Ważne

Nie twórz mockupu na sztywno. Zastosuj styl do istniejących komponentów aplikacji.
Nie usuwaj funkcji.
Nie zmieniaj API.
Nie zmieniaj danych.
Nie wprowadzaj nowej biblioteki UI, jeśli nie jest konieczna.
