# Don Bosco FIFA Responsive Theme Pack

Paczka dla Claude do wdrożenia globalnego redesignu aplikacji Don Bosco w stylu FIFA / EA Sports FC.

Logo nie jest dołączone. Dodaj je do tego samego folderu pod nazwą:

- `logoDonBosco.png` albo
- `logoDonBosco.svg`

Claude ma użyć tego pliku jako głównego logotypu w navbarze.

Zakres:
- mobile + tablet + desktop,
- dark mode + light mode,
- globalny navbar,
- globalne tokeny CSS,
- karty, tabele, buttony, bottom nav,
- bez zmiany logiki aplikacji i routingu.
