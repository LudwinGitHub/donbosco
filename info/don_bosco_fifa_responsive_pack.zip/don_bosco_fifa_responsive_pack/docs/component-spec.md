# Component spec

## Navbar

Mobile:
- logo: left, `logoDonBosco`, 56x56,
- title: centered, `Don Bosco`, orange, italic/bold,
- actions: theme toggle + hamburger,
- sticky top,
- orange bottom accent.

Desktop:
- logo + title left,
- desktop menu center,
- theme toggle right,
- hamburger hidden.

## Theme toggle

Use existing toggle logic if present. If the app already uses a class like `.dark`, keep it. Otherwise use `[data-theme="dark"]` and `[data-theme="light"]` on root element.

## Cards

All cards should use:
- rounded corners,
- subtle border,
- dark/light aware background,
- orange top accent for key statistic cards.

## Tables

Tables should inherit theme colors. Header muted, active sortable column orange.
