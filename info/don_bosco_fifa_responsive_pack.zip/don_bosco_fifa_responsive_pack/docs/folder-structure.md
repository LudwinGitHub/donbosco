# Folder structure expected by Claude

Place all files in one folder, for example:

```txt
/src/assets/don-bosco-theme/
  logoDonBosco.png
  navbar-bg.svg
  navbar-pattern.svg
  fifa-theme-tokens.css
  fifa-responsive-layout.css
```

Logo is provided separately by the user. It must be named `logoDonBosco`.
