# Design rules

- Premium sports dashboard, not generic admin panel.
- Orange is the primary brand accent; use it for active states, important numbers and navbar line.
- Keep backgrounds calm; avoid too many gradients inside content.
- Cards should feel elevated but lightweight.
- Dark mode is the primary visual direction.
- Light mode must preserve the same shape, spacing and orange identity.
- Avoid functional refactors.
